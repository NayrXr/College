# Program MesinATM
# Program yang menyimulasi cara kerja mesin ATM

# KAMUS
# PIN : int
# jenis_transaksi, bahasa, jenis_bayar, kodper : str
# bank, pin, no_rek, tipe, nominal : str
# jumlah_tarikan : int
# Transaksi, Transfer, Tarik : bool
# saldo : int
# Fungsi MasukanPIN
def Pin():
    # Menerima input untuk variabel Pin

    # Kamus Lokal
    # Pin : int
    # Transaksi : bool
    # ngisi : bool

    # Algoritma
    global Transaksi  # Membuat variabel Transaksi berpengaruh di luar fungsi
    ngisi = True
    if bahasa == 'a':
        while ngisi:  # Memaksa untuk memasukkan PIN dengan benar
            Pin = int(input("Masukkan PIN : "))
            if (Pin != 0):
                if (len(str(Pin)) == 6):
                    ngisi = False
                    print()
                else:   # (len(str(Pin)) != 6)
                    print("PIN yang Anda masukkan salah.")
                    print()
            else:   # (Pin == 0)
                print("Transaksi dibatalkan."); print("Kartu ATM dikeluarkan.")
                Transaksi = False
    else:   # bahasa == 'b'
        while ngisi:  # Memaksa untuk memasukkan PIN dengan benar
            Pin = int(input("Enter your PIN : "))
            if (Pin != 0):
                if (len(str(Pin)) == 6):
                    ngisi = False
                    print()
                else:   # (len(str(Pin)) != 6)
                    print("Incorrect PIN.")
                    print()
            else:   # (Pin == 0)
                print("Transaction is cancelled."); print("Card is removed.")
                Transaksi = False
# Fungsi PilihanAkhir
def pilihan():
    # Menanyakan keputusan untuk mengulang atau menyudahi transaksi

    # Kamus Lokal
    # Pil : str
    # Transaksi : bool

    # Algoritma
    global Transaksi  # Membuat variabel Transaksi berpengaruh di luar fungsi
    if bahasa == 'a':
        print("Ingin melakukan transaksinya berikutnya?")
        print("a. Ya"); print("b. Tidak")
        Pil = input("Pilihan Anda : ")
        print()
        # Percabangan pada fungsi pilihan
        if (Pil == 'a'):
            Transaksi = True
        elif (Pil == 'b'):
            print("Senang bertransaksi dengan Anda."); print("Kartu ATM dikeluarkan.")
            Transaksi = False
        else: # (Pil != 'a') and (Pil != 'b')
            print("Pilihan tidak tersedia.")       # Ketika memasukkan input di luar pilihan, fungsi pilihan akan dipanggil kembali
            pilihan()
    else:   # bahasa == 'b'
        print("Do you want another service?")
        print("a. Yes"); print("b. No")
        Pil = input("Your choice : ")
        print()
        # Percabangan pada fungsi choice
        if (Pil == 'a'):
            Transaksi = True
        elif (Pil == 'b'):
            print("Nice to deal with you."); print("Card is removed.")
            Transaksi = False
        else: # (Pil != 'a') and (Pil != 'b')
            print("Option is not available.")      # Ketika memasukkan input di luar pilihan, fungsi choice akan dipanggil kembali
            pilihan()
# Fungsi PencetakanResi
def resi(tipe,nominal):
    # Menanyakan keputusan untuk mencetak resi

    # Kamus Lokal
    # Res : str
    # nominal : str
    # tipe : str
    # res : array [0..1] of str

    # Algoritma
    res = ["" for i in range(0,2)]
    res[0] = tipe
    res[1] = "Rp"+nominal+",-"
    if bahasa == 'a':
        print("Cetak Resi?")
        print("a. Ya"); print("b. Tidak")
        Res = input("Pilihan Anda : ")
        print()
        # Percabangan pada fungsi "resi"
        if (Res == 'a'):
            print(res)
            print()
            pilihan()
        elif (Res == 'b'):
            print("Resi tidak dicetak")
            print()
            pilihan()
        else: # (Res != 'a') and (Res != 'b')
            print("Pilihan tidak tersedia")        # Ketika memasukkan input di luar pilihan, fungsi resi akan dipanggil kembali   
            print()
            resi(tipe,nominal)
    else:   # bahasa == 'b'
        print("Print Receipt?")
        print("a. Yes"); print("b. No")
        Res = input("Your choice : ")
        print()
        # Percabangan pada fungsi "resi"
        if (Res == 'a'):
            print(res)
            print()
            pilihan()
        elif (Res == 'b'):
            print("Receipt is not printed.")
            print()
            pilihan()
        else: # (Res != 'a') and (Res != 'b')
            print("Option is not available.")      # Ketika memasukkan input di luar pilihan, fungsi receipt akan dipanggil kembali
            print()
            resi(tipe,nominal)
# Fungsi KonfirmasiPembayaran
def konfir(tipe,nominal):
    # Menanyakan keputusan untuk meneruskan transaksi khusus pembayaran

    # Kamus Lokal
    # Konfirmasi : str
    # tipe, nominal : str
    # saldo : int
    # Transfer : bool

    # Algoritma
    global saldo          # Membuat variabel saldo berpengaruh di luar fungsi
    global Transfer       # Membuat variabel Transfer berpengaruh di luar fungsi

    if bahasa == 'a':
        print("Konfirmasi transaksi?")
        print("a. Ya"); print("b. Tidak")
        Konfirmasi = input("Pilihan Anda : ")
        print()
        if (Konfirmasi == 'a'):
            saldo = saldo - int(nominal)                   # Pengurangan Saldo
            print("Transaksi berhasil.")
            print("Sisa Saldo Anda adalah Rp" + str(saldo) + ",-")
            Transfer = False
            print()
            resi(tipe,nominal)
        elif (Konfirmasi == 'b'):
            Transfer = True
        elif (Konfirmasi == 'X') or (Konfirmasi == '0'):
            Transfer = False
            cancel()
        else:   # (Konfirmasi != 'a') and (Konfirmasi != 'b') and (Konfirmasi != 'X') and (Konfirmasi != '0')
            print("Pilihan tidak tersedia.")
            konfir(tipe,nominal)
    else:   # bahasa == 'b'
        print("Confirm transaction?")
        print("a. Yes"); print("b. No")
        Konfirmasi = input("Your choice : ")
        print()
        if (Konfirmasi == 'a'):
            saldo = saldo - int(nominal)                   # Pengurangan Saldo
            print("Transaction succeed.")
            print("Your remaining balance is Rp" + str(saldo) + ",-")
            Transfer = False
            print()
            resi(tipe,nominal)
        elif (Konfirmasi == 'b'):
            Transfer = True
        elif (Konfirmasi == 'X') or (Konfirmasi == '0'):
            Transfer = False
            cancel()
        else:   # (Konfirmasi != 'a') and (Konfirmasi != 'b') and (Konfirmasi != 'X') and (Konfirmasi != '0')
            print("Option is not available.")
            konfir(tipe,nominal)
# Prosedur TombolCancel
def cancel():
    # Memaksa untuk keluar dari program

    # Kamus
    # Transaksi : bool

    # Algoritma
    global Transaksi  # Membuat variabel Transaksi berpengaruh di luar fungsi
    if bahasa == 'a':
        print("Transaksi dibatalkan."); print("Kartu ATM dikeluarkan.")
        Transaksi = False
    else:   # bahasa == 'b'
        print("Transaction is cancelled."); print("Card is removed.")
        Transaksi = False
    
        
# ALGORITMA
# Deklarasi variabel penentu keberlanjutan transaksi
Transaksi = True

# Memulai sistem
print("Kartu ATM dimasukkan.")  # Inisialisasi
saldo = 100000000               # Saldo Awal Pemilik ATM sebanyak Rp100.000.000,-
print()

# Pemilihan bahasa
print("Pilihan bahasa/Language option :")
print("a. Indonesia"); print("b. English")
bahasa = input("Bahasa/Language : ")

while (bahasa != 'a') and (bahasa != 'b') and (bahasa != 'X') and (bahasa != '0'):           # Memaksa untuk memilih bahasa dengan benar
    bahasa = input("Bahasa/Language : ")
print()

# Keluar dari atm
if (bahasa == 'X') or (bahasa == '0'):
    print("Transaksi dibatalkan."); print("Kartu ATM dikeluarkan.")
    Transaksi = False
else:   # (bahasa == 'a') or (bahasa == 'b')
    PIN = Pin()

while Transaksi:
    # Pilihan transaksi dalam Bahasa Indonesia
    if (bahasa == 'a'):
        print("Transaksi apa yang Anda inginkan?")
        print("a. Tarik Tunai"); print("b. Transfer"); print("c. Info Saldo"); print("d. Ganti PIN"); print("e. Pembayaran")
        jenis_transaksi = input("Pilihan Anda : ")
        
        # Paksaan untuk memilih dengan benar
        while (jenis_transaksi != 'a') and (jenis_transaksi != 'b') and (jenis_transaksi != 'c') and (jenis_transaksi != 'd') and (jenis_transaksi != 'e') and (jenis_transaksi != 'X') and (jenis_transaksi != '0'):
            print("Pilihan tidak tersedia.")
            print()
            jenis_transaksi = input("Pilihan Anda : ")

        print()
        # Memilih tarik tunai
        if (jenis_transaksi == 'a'):
            Tarik = True
            while Tarik:
                tipe = "Tarik tunai"
                print("Jumlah tarikan :")
                print("a. 300 000"); print("b. 500 000"); print("c. 1 000 000"); print("d. Lainnya")
                jumlah_tarikan = input("Pilihan Anda : ")
                
                # Paksaan untuk memilih dengan benar
                while (jumlah_tarikan != 'a') and (jumlah_tarikan != 'b') and (jumlah_tarikan != 'c') and (jumlah_tarikan != 'd') and (jumlah_tarikan != 'X') and (jumlah_tarikan != '0') and (jumlah_tarikan != 'Z'):
                    print("Pilihan tidak tersedia.")
                    print()
                    jumlah_tarikan = input("Pilihan Anda : ")

                print()    
                # Pilihan nominal
                if (jumlah_tarikan == 'a'):
                    # Bagi kasus saldo tidak mencukupi
                    if (saldo < 300000):
                        print("Maaf, saldo Anda tidak mencukupi.")
                        print(); Tarik = True
                    else:   # (saldo >= 300000)
                        saldo = saldo - 300000                   # Pengurangan Saldo
                        print("Penarikan Rp300000,-")
                        print("Sisa saldo Anda adalah Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,"300000")
                elif (jumlah_tarikan == 'b'):
                    # Bagi kasus saldo tidak mencukupi
                    if (saldo < 500000):
                        print("Maaf, saldo Anda tidak mencukupi.")
                        print(); Tarik = True
                    else:   # (saldo >= 500000)
                        saldo = saldo - 500000                   # Pengurangan Saldo
                        print("Penarikan Rp500000,-")
                        print("Sisa saldo Anda adalah Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,"500000")
                elif (jumlah_tarikan == 'c'):
                    # Bagi kasus saldo tidak mencukupi
                    if (saldo < 1000000):
                        print("Maaf, saldo Anda tidak mencukupi.")
                        print(); Tarik = True
                    else:   # (saldo >= 1000000)
                        saldo = saldo - 1000000                  # Pengurangan Saldo
                        print("Penarikan Rp1000000,-")
                        print("Sisa saldo Anda adalah Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,"1000000")
                elif (jumlah_tarikan == 'd'):
                    nominal = input("Masukkan nominal : ")

                    # Loop agar memasukkan nominal uang berkelipatan 50 000 dan maksimal 1 500 000
                    while (int(nominal)%50000 != 0) or (int(nominal) > 1500000):
                        if (int(nominal)%50000 != 0):
                            print("Maaf, mesin hanya mengeluarkan uang Rp50.000,-")
                        if (int(nominal) > 1500000):
                            print("Maksimal uang yang dapat dikeluarkan adalah Rp1.500.000,-")
                        print()
                        nominal = input("Masukkan nominal : ")
                        
                    if (nominal == '0') or (nominal == 'X'):
                        Tarik = False
                        cancel()
                    # Bagi kasus saldo tidak mencukupi
                    elif (int(nominal) > saldo):
                        print("Maaf, saldo Anda tidak mencukupi.")
                        print(); Tarik = True
                    else:   # (nominal != '0') and (nominal != 'X') and (nominal <= saldo)
                        saldo = saldo - int(nominal)                  # Pengurangan Saldo
                        print("Penarikan Rp" + nominal + ",-")
                        print("Sisa saldo Anda adalah Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,nominal)
                # Kembali ke menu sebelumnya
                elif (jumlah_tarikan == 'Z'):
                    Tarik = False
                    Transaksi = True
                # Keluar dari atm
                else:   # (jumlah_tarikan == 'X') or (jumlah_tarikan == '0')
                    Tarik = False
                    cancel()

        # Memilih transfer
        elif (jenis_transaksi == 'b'):
            tipe = "Transfer"
            Transfer = True
            while Transfer:
                print("Tampilkan daftar kode bank?")
                print("a. Ya"); print("b. Tidak")
                bank = input("Pilihan Anda : ")
                
                # Paksaan untuk memilih dengan benar
                while (bank != 'a') and (bank != 'b') and (bank != 'X') and (bank != '0') and (bank != 'Z'):
                    print("Pilihan tidak tersedia.")
                    print()
                    bank = input("Pilihan Anda : ")
                print()

                # Keluar dari atm
                if (bank == 'X') or (bank == '0'):
                    Transfer = False
                    cancel()
                # Kembali ke menu sebelumnya
                elif (bank == 'Z'):
                    Transaksi = True
                    Transfer = False
                else:   # (bank == 'a') or (bank == 'b')
                    if (bank == 'a'):
                        print("Kode bank :")
                        print("101 Bank Mirza"); print("102 Bank Ferdi"); print("103 Bank Abang"); print("104 Bank Boni"); print("105 Bank Kusnadi")
                        print()
                    no_rek = input("Masukkan rekening tujuan : ")
                    print()
                    while (len(no_rek) != 10) and (len(no_rek) != 13) and (no_rek != '0') and (no_rek != 'X'):     # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5 atau 8
                        print()
                        print("Harap masukkan 10 digit.")
                        no_rek = input("Masukkan nomor rekening: ")
                    # Keluar dari atm
                    if (no_rek == 'X') or (no_rek == '0'):
                        Transfer = False
                        cancel()
                    else:   # (no_rek != 'X') and (no_rek != '0')
                        nominal = input("Masukkan nominal: ")
                        print()
                        # Keluar dari atm
                        if (nominal == '0') or (nominal == 'X'):
                            Transfer = False
                            cancel()
                        else:   # (nominal != 0) and (nominal != 'X')
                            no_ref = input("Masukkan nomor referensi (opsional) : ")
                            print()
                            # Keluar dari atm
                            if (no_ref == 'X') or (no_ref == '0'):
                                Transfer = False
                                cancel()
                            else:   # (no_ref != 'X') and (no_ref != '0')
                                # Bagi kasus saldo tidak mencukupi
                                if (saldo < int(nominal)):
                                    print("Maaf, saldo Anda tidak mencukupi.")
                                    print()
                                else:   # (saldo >= nominal)
                                    konfir(tipe,nominal)

        # Memilih info saldo
        elif (jenis_transaksi == 'c'):
            print("Sisa saldo Anda adalah Rp" + str(saldo) + ",-")
            print()
            pilihan()

        # Memilih ganti PIN
        elif (jenis_transaksi == 'd'):
            print("Apakah Anda ingin mengganti PIN?")
            print("a. Ya"); print("b. Tidak")
            pin = input("Pilihan Anda : ")
            
            # Paksaan untuk memilih dengan benar
            while (pin != 'a') and (pin != 'b') and (pin != 'X') and (pin != '0') and (pin != 'Z'):
                print("Pilihan tidak tersedia.")
                print()
                pin = input("Pilihan Anda : ")

            print()
            if (pin == 'a'):
                Pin()
                pilihan()
            # Kembali ke menu sebelumnya
            elif (pin == 'b') or (pin == 'Z'):
                Transaksi = True
            # Keluar dari atm
            else:   # (pin == 'X') or (pin == '0')
                cancel()

        # Memilih pembayaran
        elif (jenis_transaksi == 'e'):
            Transfer = True
            print("Jenis Pembayaran :")
            print("a. Internet"); print("b. UKT"); print("c. TV "); print("d. Pulsa"); print("e. Listrik"); print("f. Online Shopping")
            jenis_bayar = input("Pilihan Anda : ")

            # Paksaan untuk memilih dengan benar
            while (jenis_bayar != 'a') and (jenis_bayar != 'b') and (jenis_bayar != 'c') and (jenis_bayar != 'd') and (jenis_bayar != 'e') and (jenis_bayar != 'f') and (jenis_bayar != 'X') and (jenis_bayar != '0') and (jenis_bayar != 'Z'):
                print("Pilihan tidak tersedia.")
                print()
                jenis_bayar = input("Pilihan Anda : ")

            if (jenis_bayar == 'a'):
                tipe = "Bayar layanan internet"
            elif (jenis_bayar == 'b'):
                tipe = "Bayar UKT"
            elif (jenis_bayar == 'c'):
                tipe = "Bayar layanan televisi"
            elif (jenis_bayar == 'd'):
                tipe = "Beli pulsa"
            elif (jenis_bayar == 'e'):
                tipe = "Bayar listrik"
            elif (jenis_bayar == 'f'):
                tipe = "Belanja daring"
            else:   # (jenis_bayar == 'X') or (jenis_bayar == '0') or (jenis_bayar == 'Z')
                tipe = ""

            print()
            while Transfer:
                if (jenis_bayar == 'a') or (jenis_bayar == 'b') or (jenis_bayar == 'c') or (jenis_bayar == 'd') or (jenis_bayar == 'e') or (jenis_bayar == 'f'):
                    kodper = input("Masukkan kode perusahaan : ")
                    # Keluar dari atm
                    if (kodper == 'X') or (kodper == '0'):
                        Transfer = False
                        cancel()
                    else:   # (kodper != 'X')

                        # Paksaan untuk memilih dengan benar
                        while (len(kodper) != 5):
                            print("Harap masukkan 5 digit.")
                            print()
                            kodper = input("Masukkan kode perusahaan : ")

                        print()
                        kodpem = input("Masukkan kode pembayaran : ")
                        # Keluar dari atm
                        if (kodpem == 'X') or (kodpem == '0'):
                            Transfer = False
                            cancel()
                        else:   # (kodpem != 'X')
                            
                            # Paksaan untuk memilih dengan benar
                            while (len(kodpem) != 5):
                                print("Harap masukkan 5 digit.")
                                print()
                                kodpem = input("Masukkan kode pembayaran : ")
    
                            print()
                            nominal = input("Masukkan nominal: ")
                            print()
                            # Keluar dari atm
                            if (nominal == '0') or (nominal == 'X'):
                                Transfer = False
                                cancel()
                            else:   # (nominal != '0') and (nominal != 'X')
                                # Bagi kasus saldo tidak mencukupi
                                if (saldo < int(nominal)):
                                    print("Maaf, saldo Anda tidak mencukupi.")
                                    print()
                                else:   # (saldo >= nominal)
                                    konfir(tipe,nominal)
                # Kembali ke menu sebelumnya
                elif (jenis_bayar == 'Z'):
                    Transfer = False
                    Transaksi = True
                # Keluar dari atm
                else:   # (jenis_bayar == 'X') or (jenis_bayar == '0')
                    Transfer = False
                    cancel()
                    
        # Keluar dari atm
        else:   # (jenis_transaksi == 'X') or (jenis_transaksi == '0')
            cancel()

    # Pilihan transaksi dalam Bahasa Inggris
    else:   # (bahasa == 'b'):
        print("What kind of transaction do you want?")
        print("a. Cash Withdrawal"); print("b. Transfer"); print("c. Balance Info"); print("d. Change PIN"); print("e. Payment")
        jenis_transaksi = input("Your choice : ")
        
        # Paksaan untuk memilih dengan benar
        while (jenis_transaksi != 'a') and (jenis_transaksi != 'b') and (jenis_transaksi != 'c') and (jenis_transaksi != 'd') and (jenis_transaksi != 'e') and (jenis_transaksi != 'X') and (jenis_transaksi != '0'):
            print("Option is not available.")
            print()
            jenis_transaksi = input("Your choice : ")

        print()
        # Memilih tarik tunai
        if (jenis_transaksi == 'a'):
            Tarik = True
            while Tarik:
                tipe = "Cash withdrawal"
                print("Amount of withdrawal :")
                print("a. 300 000"); print("b. 500 000"); print("c. 1 000 000"); print("d. Others")
                jumlah_tarikan = input("Your choice : ")
                
                # Paksaan untuk memilih dengan benar
                while (jumlah_tarikan != 'a') and (jumlah_tarikan != 'b') and (jumlah_tarikan != 'c') and (jumlah_tarikan != 'd') and (jumlah_tarikan != 'X') and (jumlah_tarikan != '0') and (jumlah_tarikan != 'Z'):
                    print("Option is not available.")
                    print()
                    jumlah_tarikan = input("Your choice : ")

                print()    
                # Pilihan nominal
                if (jumlah_tarikan == 'a'):
                    # Bagi kasus saldo tidak mencukupi
                    if (saldo < 300000):
                        print("Sorry, you have insufficient funds.")
                        print(); Tarik = True
                    else:   # (saldo >= 300000)
                        saldo = saldo - 300000                   # Pengurangan Saldo
                        print("Withdraw Rp300000,-")
                        print("Your remaining balance is Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,"300000")
                elif (jumlah_tarikan == 'b'):
                    # Bagi kasus saldo tidak mencukupi
                    if (saldo < 300000):
                        print("Sorry, you have insufficient funds.")
                        print(); Tarik = True
                    else:   # (saldo >= 300000)
                        saldo = saldo - 500000                   # Pengurangan Saldo
                        print("Withdraw Rp500000,-")
                        print("Your remaining balance is Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,"500000")
                elif (jumlah_tarikan == 'c'):
                    # Bagi kasus saldo tidak mencukupi
                    if (saldo < 300000):
                        print("Sorry, you have insufficient funds.")
                        print(); Tarik = True
                    else:   # (saldo >= 300000)
                        saldo = saldo - 1000000                  # Pengurangan Saldo
                        print("Withdraw Rp1000000,-")
                        print("Your remaining balance is Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,"1000000")
                elif (jumlah_tarikan == 'd'):
                    nominal = input("Masukkan nominal : ")
                    
                    # Loop agar memasukkan nominal uang berkelipatan 50 000 dan maksimal 1 500 000
                    while (int(nominal)%50000 != 0) or (int(nominal) > 1500000):
                        if (int(nominal)%50000 != 0):
                            print("Sorry, the machine can only give Rp50.000,- money.")
                        if (int(nominal) > 1500000):
                            print("The maximum amount of withdrawn money is Rp1.500.000,-")
                        print()
                        nominal = input("Masukkan nominal : ")
                        
                    if (nominal == '0') or (nominal == 'X'):
                        Tarik = False
                        cancel()
                    # Bagi kasus saldo tidak mencukupi
                    elif (int(nominal) > saldo):
                        print("Sorry, you have insufficient funds.")
                        print(); Tarik = True
                    else:   # (nominal != '0') and (nominal != 'X') and (nominal <= saldo)
                        saldo = saldo - int(nominal)                  # Pengurangan Saldo
                        print("Withdraw Rp" + nominal + ",-")
                        print("Your remaining balance is Rp" + str(saldo) + ",-")
                        print(); Tarik = False
                        resi(tipe,nominal)
                # Kembali ke menu sebelumnya
                elif (jumlah_tarikan == 'Z'):
                    Tarik = False
                    Transaksi = True
                # Keluar dari atm
                else:   # (jumlah_tarikan == 'X') or (jumlah_tarikan == '0')
                    Tarik = False
                    cancel()

        # Memilih transfer
        elif (jenis_transaksi == 'b'):
            tipe = "Transfer"
            Transfer = True
            while Transfer:
                print("Show code bank list?")
                print("a. Yes"); print("b. No")
                bank = input("Your choice : ")
                
                # Paksaan untuk memilih dengan benar
                while (bank != 'a') and (bank != 'b') and (bank != 'X') and (bank != '0') and (bank != 'Z'):
                    print("Option is not available.")
                    print()
                    bank = input("Your choice : ")
                print()

                # Keluar dari atm
                if (bank == 'X') or (bank == '0'):
                    Transfer = False
                    cancel()
                # Kembali ke menu sebelumnya
                elif (bank == 'Z'):
                    Transaksi = True
                    Transfer = False
                else:   # (bank == 'a') or (bank == 'b')
                    if (bank == 'a'):
                        print("Bank code :")
                        print("101 Bank Mirza"); print("102 Bank Ferdi"); print("103 Bank Abang"); print("104 Bank Boni"); print("105 Bank Kusnadi")
                        print()
                    no_rek = input("Enter account number : ")
                    print()
                    while (len(no_rek) != 10) and (len(no_rek) != 13):     # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5 atau 8
                        print("Please enter 10 digits.")
                        no_rek = input("Enter account number : ")
                        print()
                    # Keluar dari atm
                    if (no_rek == 'X') or (no_rek == '0'):
                        Transfer = False
                        cancel()
                    else:   # (no_rek != 'X') and (no_rek != '0')
                        nominal = input("Enter nominal : ")
                        print()
                        # Keluar dari atm
                        if (nominal == '0') or (nominal == 'X'):
                            Transfer = False
                            cancel()
                        else:   # (nominal != '0') and (nominal != 'X')
                            no_ref = input("Enter reference number (optional) : ")
                            print()
                            # Keluar dari atm
                            if (no_ref == 'X') or (no_ref == '0'):
                                Transfer = False
                                cancel()
                            else:   # (no_ref != 'X') and (no_ref != '0')
                                # Bagi kasus saldo tidak mencukupi
                                if (saldo < int(nominal)):
                                    print("Sorry, you have insufficient funds.")
                                    print()
                                else:   # (saldo >= int(nominal)
                                    konfir(tipe,nominal)

        # Memilih info saldo
        elif (jenis_transaksi == 'c'):
            print("Your remaining balance is Rp" + str(saldo) + ",-")
            print()
            pilihan()

        # Memilih ganti PIN
        elif (jenis_transaksi == 'd'):
            print("Do you want to change your PIN?")
            print("a. Yes"); print("b. No")
            pin = input("Your choice : ")
            
            # Paksaan untuk memilih dengan benar
            while (pin != 'a') and (pin != 'b') and (pin != 'X') and (pin != '0') and (pin != 'Z'):
                print("Option is not available.")
                print()
                pin = input("Your choice : ")

            print()
            if (pin == 'a'):
                Pin()
                pilihan()
            # Kembali ke menu sebelumnya
            elif (pin == 'b') or (pin == 'Z'):
                Transaksi = True
            # Keluar dari atm
            else:   # (pin == 'X') or (pin == '0')
                cancel()

        # Memilih pembayaran
        elif (jenis_transaksi == 'e'):
            Transfer = True
            print("Type of payment :")
            print("a. Internet"); print("b. Tuition"); print("c. Television "); print("d. Recharge voucher"); print("e. Electricity bill"); print("f. Online Shopping")
            jenis_bayar = input("Your choice : ")

            # Paksaan untuk memilih dengan benar
            while (jenis_bayar != 'a') and (jenis_bayar != 'b') and (jenis_bayar != 'c') and (jenis_bayar != 'd') and (jenis_bayar != 'e') and (jenis_bayar != 'f') and (jenis_bayar != 'X') and (jenis_bayar != '0') and (jenis_bayar != 'Z'):
                print("Option is not available.")
                print()
                jenis_bayar = input("Your choice : ")

            if (jenis_bayar == 'a'):
                tipe = "Internet service"
            elif (jenis_bayar == 'b'):
                tipe = "Tuition fee"
            elif (jenis_bayar == 'c'):
                tipe = "Television service"
            elif (jenis_bayar == 'd'):
                tipe = "Voucher recharge"
            elif (jenis_bayar == 'e'):
                tipe = "Electricity bill"
            elif (jenis_bayar == 'f'):
                tipe = "Online shopping"
            else:   # (jenis_bayar == 'X') or (jenis_bayar == '0') or (jenis_bayar == 'Z')
                tipe = ""

            print()
            while Transfer:
                if (jenis_bayar == 'a') or (jenis_bayar == 'b') or (jenis_bayar == 'c') or (jenis_bayar == 'd') or (jenis_bayar == 'e') or (jenis_bayar == 'f'):
                    kodper = input("Enter company code : ")
                    # Keluar dari atm
                    if (kodper == 'X') or (kodper == '0'):
                        Transfer = False
                        cancel()
                    else:   # (kodper != 'X')

                        # Paksaan untuk memilih dengan benar
                        while (len(kodper) != 5):
                            print("Please input 5 digits.")
                            print()
                            kodper = input("Enter company code : ")

                        print()
                        kodpem = input("Enter payment code : ")
                        # Keluar dari atm
                        if (kodpem == 'X') or (kodpem == '0'):
                            Transfer = False
                            cancel()
                        else:   # (kodpem != 'X')
                            
                            # Paksaan untuk memilih dengan benar
                            while (len(kodpem) != 5):
                                print("Please input 5 digits.")
                                print()
                                kodpem = input("Enter payment code : ")
    
                            print()
                            nominal = input("Enter nominal : ")
                            print()
                            # Keluar dari atm
                            if (nominal == '0') or (nominal == 'X'):
                                Transfer = False
                                cancel()
                            else:   # (nominal != '0') and (nominal != 'X')
                                # Bagi kasus saldo tidak mencukupi
                                if (saldo < int(nominal)):
                                    print("Maaf, saldo Anda tidak mencukupi.")
                                    print()
                                else:   # (saldo >= nominal)
                                    konfir(tipe,nominal)
                # Kembali ke menu sebelumnya
                elif (jenis_bayar == 'Z'):
                    Transfer = False
                    Transaksi = True
                # Keluar dari atm
                else:   # (jenis_bayar == 'X') or (jenis_bayar == '0')
                    Transfer = False
                    cancel()
                    
        # Keluar dari atm
        else:   # (jenis_transaksi == 'X') or (jenis_transaksi == '0')
            cancel()
