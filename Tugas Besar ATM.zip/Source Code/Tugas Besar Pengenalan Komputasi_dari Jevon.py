# Program < Mesin ATM >
# Program yang menyimulasi cara kerja mesin ATM

# KAMUS
# saldo, nominal ; integer
# PIN, 

# ALGORITMA
print("Kartu ATM dimasukkan.") #Inisialisasi
saldo = 100000000   # Saldo Awal Pemilik ATM
def start():
    # Pemilihan Bahasa
    x = input("\nPilihan Bahasa: \na. Bahasa Indonesia \nb. Bahasa Inggris \nPilihan Anda: ")

    # BAHASA INDONESIA
    if (x == 'a'):
        def pin():  # Pembuatan fungsi "pin"
            PIN = input("\nMasukkan PIN: ")
            
            if (len(PIN) == 6):
                def transaksi():    # Pembuatan fungsi "transaksi"

                    def choice():   # Pembuatan fungsi "choice" 
                        a = input("\nIngin melakukan transaksinya berikutnya? \na. Ya \nb. Tidak \nPilihan Anda: ")
                        # Percabangan pada fungsi "choice"
                        if (a == 'a'):
                            transaksi()
                        elif (a == 'b'):
                            print("Senang bertransaksi dengan Anda. \nKartu ATM dikeluarkan.")
                        else:
                            print("\nPilihan tidak tersedia")   # Ketika memasukkan input di luar pilihan, maka fungsi "choice" akan dipanggil kemabali
                            choice()
                                    
                    def resi():     # Pembuatan fungsi "resi"
                        b = input("\nCetak Resi? \na. Ya \nb. Tidak \nPilihan Anda: ")
                        # Percabangan pada fungsi "resi"
                        if (b == 'a'):
                            print("Resi dicetak")
                            choice()
                        elif (b == 'b'):
                            print("Resi tidak dicetak")
                            choice()
                        else:
                            print("\nPilihan tidak tersedia")   # Ketika memasukkan input di luar pilihan, maka fungsi "resi" akan dipanggil kembali   
                            resi()

                    # Daftar pilihan menu
                    jenis_transaksi = input("\nTransaksi apa yang anda inginkan? \na. Tarik Tunai \nb. Transfer \nc. Info Saldo \nd. Ganti PIN \ne. Pembayaran \nPilihan Anda: ")

                    # Percabangan pada fungsi "transaksi"
                    if (jenis_transaksi == 'a'):
                        def tarikan():  # Pembuatan fungsi "tarikan"
                            global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                            
                            jumlah_tarikan = input("\nJumlah tarikan : \na. 300.000 \nb. 500.000 \nc. 1.000.000 \nd. Lainnya \nPilihan Anda: ")
                            # Percabangan pada fungsi "tarikan"
                            if (jumlah_tarikan == 'a'):
                                saldo -= 300000 # Pengurangan Saldo
                                print("Penarikan Rp300.000 \nSisa Saldo = Rp" + str(saldo))
                                resi()
                            elif (jumlah_tarikan == 'b'):
                                saldo -= 500000 # Pengurangan Saldo
                                print("Penarikan Rp500.000 \nSisa Saldo = Rp" + str(saldo))
                                resi()
                            elif (jumlah_tarikan == 'c'):
                                saldo -= 1000000 # Pengurangan Saldo
                                print("Penarikan Rp1.000.000 \nSisa Saldo = Rp" + str(saldo))
                                resi()
                            elif (jumlah_tarikan == 'd'):
                                nominal = int(input("\nMasukkan nominal: "))
                                saldo -= nominal # Pengurangan Saldo
                                print("Penarikkan Rp" + str(nominal) + "\nSisa Saldo = Rp" + str(saldo))
                                resi()
                            else:
                                print("\nPilihan tidak tersedia")   # Ketika memasukkan input di luar pilihan, maka fungsi "tarikan" akan dipanggil kembali   
                                tarikan()
                        tarikan()   # Pemanggilan fungsi "tarikan"

                    elif (jenis_transaksi == 'b'):
                        def transfer():     # Pembuatan fungsi "transfer"
                            def no_rek():   # Pembuatan fungsi "no_rek"
                                global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                                
                                rekening = input("Masukkan nomor rekening: ")
                                while (len(rekening) < 5 or len(rekening) > 5):     # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nHarap masukkan 5 digit")
                                    rekening = input("Masukkan nomor rekening: ")
                                    
                                nominal = int(input("Masukkan nominal: "))
                                while (nominal <= 0):                               # Sistem akan meminta input secara terus - menerus jika nilai nominal kurang dari atau sama dengan 0
                                    print("\nHarap masukkan nominal di atas 0") 
                                    nominal = int(input("Masukkan nominal: "))
                                
                                referensi = input("Masukkan nomor referensi: ")
                                while (len(referensi) < 5 or len(referensi) > 5):   # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nHarap masukkan 5 digit")
                                    referensi = input("Masukkan nomor referensi: ")
                                    
                                def konfir():# Pembuatan fungsi "konfir"
                                    global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                                    
                                    konfir = input("Konfirmasi transfer? \na. Ya \nb. Tidak \nPilihan Anda: ")
                                    if (konfir == 'a'):
                                        saldo = saldo - nominal # Pengurangan Saldo
                                        print("Transfer berhasil")
                                        print("Pembayaran Rp" + str(nominal) + "\nSisa Saldo = Rp" + str(saldo))
                                        resi()
                                    elif (konfir == 'b'):
                                        no_rek()
                                    else:
                                        print("\nPilihan tidak tersedia")   # Ketika memasukkan input di luar pilihan, maka fungsi "konfir" akan dipanggil kembali   
                                        konfir()
                                konfir() # Pemanggilan fungsi "konfir"
                            kode_bank = input("\nLihat kode bank? \na. Ya \nb. Tidak \nPilihan Anda: ")
                            if (kode_bank == 'a'):
                                print("\nKode Bank: \n1. \n2. \n3. \n4. \n5. ")
                                no_rek()
                            elif (kode_bank == 'b'):
                                no_rek()
                            else:
                                print("\nPilihan tidak tersedia")           # Ketika memasukkan input di luar pilihan, maka fungsi "transfer" akan dipanggil kembali   
                                transfer()
                        transfer()      # Pemanggilan fungsi "transfer"
                        
                    elif (jenis_transaksi == 'c'):
                        print("\nSisa saldo Anda adalah: Rp" + str(saldo))
                        choice()
                        
                    elif (jenis_transaksi == 'd'):
                        def PIN_baru():
                            pin_baru = input("\nMasukkan PIN baru: ")
                            if (len(pin_baru) == 6):
                                PIN = pin_baru
                                choice()
                            else:
                                print("\nHarap masukkan 6 angka.")
                                PIN_baru()
                        PIN_baru()      # Pemanggilan fungsi "PIN_baru"
                          
                    elif (jenis_transaksi == 'e'):
                        def bayar():
                            global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                            
                            jenis_bayar = input("Jenis Pembayaran: \n1. Internet \n2. UKT \n3. TV \n4. Pulsa \n5. Listrik \n6. Online Shopping \nPilihan Anda: ")
                            if (jenis_bayar == '1' or jenis_bayar == '2' or jenis_bayar == '3' or jenis_bayar == '4' or jenis_bayar == '5' or jenis_bayar == '6'):
                                
                                kode_perusahaan = input("Masukkan kode perusahaan: ")
                                while (len(kode_perusahaan) < 5 or len(kode_perusahaan) > 5):# Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nHarap masukkan 5 digit")
                                    kode_perusahaan = input("Masukkan kode perusahaan: ")
                                    
                                kode_pembeli = input("Masukkan kode pembeli: ")
                                while (len(kode_pembeli) < 5 or len(kode_pembeli) > 5):     # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nHarap masukan 5 digit")
                                    kode_pembeli = input("Masukkan kode pembeli: ")
                                    
                                nominal = int(input("Masukkan nominal: "))
                                while (nominal < 0):                                        # Sistem akan meminta input secara terus - menerus jika nilai nominal kurang dari atau sama dengan 0
                                    print("\nHarap masukkan nominal di atas 0")
                                    nominal = int(input("Masukkan nominal: "))
                                saldo = saldo - nominal # Pengurangan Saldo

                            else:
                                print("\nPilihan tidak tersedia")
                                bayar()
                            def konfirmasi():
                                konfir = input("Konfirmasi transfer? \na. Ya \nb. Tidak \nPilihan Anda: ")
                                if (konfir == 'a'):
                                    print("Pembayaran Rp" + str(nominal) + "\nSisa Saldo = Rp" + str(saldo))
                                    resi()
                                elif (konfir == 'b'):
                                    bayar()
                                else:
                                    print("\nPilihan tidak tersedia")   # Ketika memasukkan input di luar pilihan, maka fungsi "konfirmasi" akan dipanggil kembali   
                                    konfirmasi()
                            konfirmasi()    # Pemanggilan fungsi "konfirmasi"
                        bayar() # Pemanggilan fungsi "bayar"
                transaksi()     # Pemanggilan fungsi "transaksi"
            else: # Ketika memasukkan input di luar pilihan, proses akan diulang dengan memanggil fungsi "pin" kembali
                print("\nPIN yang anda masukkan salah.")
                pin()
        pin() # Pemanggilan fungsi "pin"

    # BAHASA INGGRIS
    elif (x == 'b'):
        def pin():  # Pembuatan fungsi "pin"
            PIN = input("\nPlease input your PIN: ")
            
            if (len(PIN) == 6):
                def transaksi():    # Pembuatan fungsi "transaksi"

                    def choice():   # Pembuatan fungsi "choice" 
                        a = input("\nDo you want to create new transaction? \na. Yes \nb. No \nYour choice: ")
                        # Percabangan pada fungsi "choice"
                        if (a == 'a'):
                            transaksi()
                        elif (a == 'b'):
                            print("Nice to deal with you. \nATM Card issued.")
                        else:
                            print("\nOption not available")   # Ketika memasukkan input di luar pilihan, maka fungsi "choice" akan dipanggil kemabali
                            choice()
                                    
                    def resi():     # Pembuatan fungsi "resi"
                        b = input("\nPrint Receipt? \na. Yes \nb. No \nYour choice: ")
                        # Percabangan pada fungsi "resi"
                        if (b == 'a'):
                            print("Receipt is printed")
                            choice()
                        elif (b == 'b'):
                            print("Receipt is not printed")
                            choice()
                        else:
                            print("\nOption not availabel")   # Ketika memasukkan input di luar pilihan, maka fungsi "resi" akan dipanggil kembali   
                            resi()

                    # Daftar pilihan menu
                    jenis_transaksi = input("\nWhat kind of transaction do you want? \na. Cash Withdrawal \nb. Transfer \nc. Balance Info \nd. Change PIN \ne. Payment \nYour choice: ")

                    # Percabangan pada fungsi "transaksi"
                    if (jenis_transaksi == 'a'):
                        def tarikan():  # Pembuatan fungsi "tarikan"
                            global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                            
                            jumlah_tarikan = input("\nNumber of pulls : \na. 300.000 \nb. 500.000 \nc. 1.000.000 \nd. Other \nYour choice: ")
                            # Percabangan pada fungsi "tarikan"
                            if (jumlah_tarikan == 'a'):
                                saldo -= 300000 # Pengurangan Saldo
                                print("Withdrawal Rp300.000 \nThe remaining balance = Rp" + str(saldo))
                                resi()
                            elif (jumlah_tarikan == 'b'):
                                saldo -= 500000 # Pengurangan Saldo
                                print("Withdrawal Rp500.000 \nThe remaining balance = Rp" + str(saldo))
                                resi()
                            elif (jumlah_tarikan == 'c'):
                                saldo -= 1000000 # Pengurangan Saldo
                                print("Withdrawal Rp1.000.000 \nThe remaining balance = Rp" + str(saldo))
                                resi()
                            elif (jumlah_tarikan == 'd'):
                                nominal = int(input("\nEnter nominal: "))
                                saldo -= nominal # Pengurangan Saldo
                                print("Withdrawal Rp" + str(nominal) + "\nSisa Saldo = Rp" + str(saldo))
                                resi()
                            else:
                                print("\nOption not available")   # Ketika memasukkan input di luar pilihan, maka fungsi "tarikan" akan dipanggil kembali   
                                tarikan()
                        tarikan()   # Pemanggilan fungsi "tarikan"

                    elif (jenis_transaksi == 'b'):
                        def transfer():     # Pembuatan fungsi "transfer"
                            def no_rek():   # Pembuatan fungsi "no_rek"
                                global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                                
                                rekening = input("Enter account number: ")
                                while (len(rekening) < 5 or len(rekening) > 5):     # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nPlease input 5 digits")
                                    rekening = input("Enter account number: ")
                                    
                                nominal = int(input("Enter nominal: "))
                                while (nominal <= 0):                               # Sistem akan meminta input secara terus - menerus jika nilai nominal kurang dari atau sama dengan 0
                                    print("\nPlease enter nominal above 0") 
                                    nominal = int(input("Enter nominal: "))
                                
                                referensi = input("Enter reference number: ")
                                while (len(referensi) < 5 or len(referensi) > 5):   # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nPlease input 5 digits")
                                    referensi = input("Enter reference number: ")
                                    
                                def konfir():# Pembuatan fungsi "konfir"
                                    global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                                    
                                    konfir = input("Confirm Transfer? \na. Yes \nb. No \nYour choice: ")
                                    if (konfir == 'a'):
                                        saldo = saldo - nominal # Pengurangan Saldo
                                        print("Transfer succeed")
                                        print("Payment Rp" + str(nominal) + "\nThe remaining balance = Rp" + str(saldo))
                                        resi()
                                    elif (konfir == 'b'):
                                        no_rek()
                                    else:
                                        print("\nOption not available")   # Ketika memasukkan input di luar pilihan, maka fungsi "konfir" akan dipanggil kembali   
                                        konfir()
                                konfir() # Pemanggilan fungsi "konfir"
                            kode_bank = input("\nDo you want to see bank code? \na. Yes \nb. No \nYour choice: ")
                            if (kode_bank == 'a'):
                                print("\nBank Code: \n1. \n2. \n3. \n4. \n5. ")
                                no_rek()
                            elif (kode_bank == 'b'):
                                no_rek()
                            else:
                                print("\nOption not available")           # Ketika memasukkan input di luar pilihan, maka fungsi "transfer" akan dipanggil kembali   
                                transfer()
                        transfer()      # Pemanggilan fungsi "transfer"
                        
                    elif (jenis_transaksi == 'c'):
                        print("\nThe remaining of your balance is: Rp" + str(saldo))
                        choice()
                        
                    elif (jenis_transaksi == 'd'):
                        def PIN_baru():
                            pin_baru = input("\nEnter new PIN: ")
                            if (len(pin_baru) == 6):
                                PIN = pin_baru
                                choice()
                            else:
                                print("\nPlease input 6 digits.")
                                PIN_baru()
                        PIN_baru()      # Pemanggilan fungsi "PIN_baru"
                          
                    elif (jenis_transaksi == 'e'):
                        def bayar():
                            global saldo# Deklarasi global agar variabel saldo bisa digunakan secara universal
                            
                            jenis_bayar = input("Type of payment: \n1. Internet \n2. UKT \n3. TV \n4. Pulse \n5. Electricity \n6. Online Shopping \nYour choice: ")
                            if (jenis_bayar == '1' or jenis_bayar == '2' or jenis_bayar == '3' or jenis_bayar == '4' or jenis_bayar == '5' or jenis_bayar == '6'):
                                
                                kode_perusahaan = input("Enter company code: ")
                                while (len(kode_perusahaan) < 5 or len(kode_perusahaan) > 5):# Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nPlease input 5 digits")
                                    kode_perusahaan = input("Enter company code: ")
                                    
                                kode_pembeli = input("Enter buyer code: ")
                                while (len(kode_pembeli) < 5 or len(kode_pembeli) > 5):     # Sistem akan meminta input secara terus - menerus jika jumlah digit tidak sama dengan 5
                                    print("\nPlease input 5 digits")
                                    kode_pembeli = input("Enter buyer code: ")
                                    
                                nominal = int(input("Enter nominal: "))
                                while (nominal < 0):                                        # Sistem akan meminta input secara terus - menerus jika nilai nominal kurang dari atau sama dengan 0
                                    print("\nPlease enter nominal above 0")
                                    nominal = int(input("Enter nominal: "))
                                saldo = saldo - nominal # Pengurangan Saldo

                            else:
                                print("\nOption not available")
                                bayar()
                            def konfirmasi():
                                konfir = input("Confirm Transfer? \na. Yes \nb. No \nyour choice: ")
                                if (konfir == 'a'):
                                    print("Payment Rp" + str(nominal) + "\nThe remaining of balance = Rp" + str(saldo))
                                    resi()
                                elif (konfir == 'b'):
                                    bayar()
                                else:
                                    print("\nOption not available")   # Ketika memasukkan input di luar pilihan, maka fungsi "konfirmasi" akan dipanggil kembali   
                                    konfirmasi()
                            konfirmasi()    # Pemanggilan fungsi "konfirmasi"
                        bayar() # Pemanggilan fungsi "bayar"
                transaksi()     # Pemanggilan fungsi "transaksi"
            else: # Ketika memasukkan input di luar pilihan, proses akan diulang dengan memanggil fungsi "pin" kembali
                print("\nYou input the incorrect PIN.")
                pin()
        pin() # Pemanggilan fungsi "pin"

start() # Pemanggilan fungsi "start"
    
